# -*- coding: utf-8 -*-
import io
p="index.html"
s=io.open(p,encoding="utf-8").read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n, "count %d for: %s" % (c, old[:70]); s=s.replace(old,new)

# ---------- IMPOSTAZIONI: telefono, dati, sincronizzazione ----------
rep("""    <h2>Aspetto</h2>""",
"""    <h2>Sul telefono</h2>
    <div class="card">
      ${inApp() ? `
      <div class="row">
        <div class="rbody">
          <div class="rtitle">Notifiche</div>
          <div class="rmeta">${S.push.on ? "Accese" : "Spente"}. Programmo i prossimi sette giorni: la giornata al mattino, gli eventi mezz'ora prima, la valigia la sera prima, le uscite e le scadenze.</div>
        </div>
        <button class="btn ${S.push.on ? "primary" : ""}" id="op-push">${S.push.on ? "Accese" : "Spente"}</button>
      </div>
      <div class="row">
        <div class="rbody">
          <div class="rtitle">Il riassunto del mattino</div>
          <div class="rmeta">A che ora ti dico cosa c'è da fare.</div>
        </div>
        <input type="time" id="op-pushora" value="${S.push.ora}" style="width:112px;padding:10px;border:1px solid var(--line);border-radius:10px;background:var(--surface)">
      </div>
      <div class="row">
        <div class="rbody">
          <div class="rtitle">Avviso della chiusura serale</div>
          <div class="rmeta">All'ora che hai scelto qui sopra per chiudere la giornata.</div>
        </div>
        <button class="btn ${S.push.sera ? "primary" : ""}" id="op-pushsera">${S.push.sera ? "Sì" : "No"}</button>
      </div>
      <div class="row">
        <div class="rbody">
          <div class="rtitle">Sveglia domattina</div>
          <div class="rmeta">La metto nell'orologio del telefono: suona anche se l'app è chiusa.</div>
        </div>
        <input type="time" id="op-sveglia" value="${S.wake || "07:00"}" style="width:112px;padding:10px;border:1px solid var(--line);border-radius:10px;background:var(--surface)">
      </div>
      <div class="row"><button class="btn wide" id="op-metti-sveglia">Metti la sveglia</button></div>
      <div class="row">
        <div class="rbody">
          <div class="rtitle">Permesso per gli orari esatti</div>
          <div class="rmeta">Senza, Android può far scivolare le notifiche di qualche minuto.</div>
        </div>
        <button class="btn" id="op-esatte">Apri</button>
      </div>`
      : `<div class="empty">Qui dentro non posso mandarti notifiche: questa è una pagina nel browser. Nell'app Android compaiono notifiche, sveglie e timer.</div>`}
    </div>

    <h2>I tuoi dati</h2>
    <div class="card">
      <div class="row">
        <div class="rbody">
          <div class="rtitle">Backup</div>
          <div class="rmeta">Un file con dentro tutto: attività, storico, conti, vini, diario. Tienilo da parte.</div>
        </div>
      </div>
      <div class="row" style="gap:9px">
        <button class="btn" id="op-export" style="flex:1">Esporta</button>
        <button class="btn ghost" id="op-import" style="flex:1">Importa</button>
      </div>
    </div>

    <h2>Sincronizzazione</h2>
    <div class="card">
      <div class="row">
        <div class="rbody">
          <div class="rtitle">Fra i tuoi dispositivi</div>
          <div class="rmeta">${syncPronto()
            ? `Collegata a ${esc(S.sync.repo)}. ${S.sync.last ? `Ultima volta: ${new Date(S.sync.last).toLocaleString("it-IT")}.` : ""}`
            : "Metti un deposito GitHub privato e un token: i dati vivono lì, e ogni telefono vede le stesse cose."}</div>
          ${SYNCSTATO !== "fermo" ? `<div class="rmeta" style="color:${String(SYNCSTATO).startsWith("errore") ? "var(--warn)" : "var(--done)"}">${esc(String(SYNCSTATO))}</div>` : ""}
        </div>
      </div>
      <div class="row" style="display:block">
        <div class="field" style="margin-bottom:10px"><label>Deposito (utente/nome)</label>
          <input type="text" id="op-repo" value="${esc(S.sync.repo || "")}" placeholder="tuonome/coach-dati" autocapitalize="off" autocorrect="off"></div>
        <div class="field" style="margin-bottom:10px"><label>Token</label>
          <input type="password" id="op-token" value="${esc(S.sync.token || "")}" placeholder="github_pat_…" autocapitalize="off" autocorrect="off"></div>
        <div class="hint">Il token resta solo su questo dispositivo. Serve un token “fine-grained” con permesso Contents: lettura e scrittura, solo su quel deposito.</div>
      </div>
      <div class="row" style="gap:9px">
        <button class="btn primary" id="op-sync" style="flex:2">Salva e sincronizza</button>
        <button class="btn ghost" id="op-syncauto" style="flex:1">${S.sync.auto ? "Auto: sì" : "Auto: no"}</button>
      </div>
    </div>

    <h2>Aspetto</h2>""")

rep("""  el.querySelector("#op-pause").onclick = () => { if (isPaused()) endPause(); else openPause(""); };""",
"""  const q = id => el.querySelector("#" + id);
  const push = q("op-push");
  if (push) push.onclick = () => { S.push.on = !S.push.on; save(); render(); };
  const pushora = q("op-pushora");
  if (pushora) pushora.onchange = e => { S.push.ora = e.target.value || "08:00"; save(); render(); };
  const pushsera = q("op-pushsera");
  if (pushsera) pushsera.onclick = () => { S.push.sera = !S.push.sera; save(); render(); };
  const mettiSv = q("op-metti-sveglia");
  if (mettiSv) mettiSv.onclick = () => {
    const ora = q("op-sveglia") ? q("op-sveglia").value : S.wake;
    if (!svegliaTelefono(ora, "Coach")) alert("La sveglia si mette dall'app Android.");
  };
  const esatte = q("op-esatte");
  if (esatte) esatte.onclick = () => { try { NAT.apriImpostazioniSveglie(); } catch(e){} };

  q("op-export").onclick = () => esportaBackup();
  q("op-import").onclick = () => importaBackup();
  q("op-sync").onclick = () => {
    S.sync.repo = q("op-repo").value.trim().replace(/^https?:\\/\\/github\\.com\\//, "").replace(/\\.git$/, "");
    S.sync.token = q("op-token").value.trim();
    S.sync.sha = null;
    save();
    sincronizza();
  };
  q("op-syncauto").onclick = () => { S.sync.auto = !S.sync.auto; save(); render(); };

  el.querySelector("#op-pause").onclick = () => { if (isPaused()) endPause(); else openPause(""); };""")

# ---------- il crono può usare il timer del telefono ----------
rep("""    <div class="btnrow"><button class="btn primary wide" id="cr-add">Nuovo ciclo</button></div>""",
"""    ${inApp() ? `<div class="btnrow"><button class="btn wide" id="cr-timer">Timer nell'orologio del telefono</button></div>` : ""}
    <div class="btnrow"><button class="btn primary wide" id="cr-add">Nuovo ciclo</button></div>""")

rep("""  w.querySelector("#cr-add").onclick = () => { w.remove(); openCycle(null); };""",
"""  w.querySelector("#cr-add").onclick = () => { w.remove(); openCycle(null); };
  const crt = w.querySelector("#cr-timer");
  if (crt) crt.onclick = () => {
    const m = prompt("Quanti minuti?", "25");
    if (m && +m > 0){ timerTelefono(+m, "Coach"); w.remove(); }
  };""")

# ---------- avvio: guardiano offline, notifiche, sincronizzazione ----------
rep("""(async () => {
  await loadState();
  runEngine();
  render();
  gcalStart();
})();""",
"""// il guardiano offline: c'è solo quando l'app vive su un sito vero
if ("serviceWorker" in navigator && location.protocol.indexOf("http") === 0){
  window.addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => {}));
}

(async () => {
  await loadState();
  runEngine();
  render();
  gcalStart();
  riprogrammaAvvisi();
  if (syncPronto()) sincronizza();
})();

// tornando dentro dopo un po': ricontrolla se un altro dispositivo ha scritto
document.addEventListener("visibilitychange", () => {
  if (document.hidden) return;
  if (syncPronto() && S.sync.auto && (!S.sync.last || Date.now() - S.sync.last > 60000)) sincronizza();
});""")

rep("""versione 23""","""versione 24""")

io.open(p,"w",encoding="utf-8").write(s)
print("ok")
