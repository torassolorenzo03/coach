# -*- coding: utf-8 -*-
import io
p="index.html"
s=io.open(p,encoding="utf-8").read()
def rep(old,new,n=1):
    global s
    c=s.count(old); assert c==n, "count %d for: %s" % (c, old[:70]); s=s.replace(old,new)

# ---------- testa: manifest, icone, colore ----------
rep("""<title>Coach</title>""",
"""<title>Coach</title>
<link rel="manifest" href="manifest.webmanifest">
<meta name="theme-color" content="#1F6F63">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<link rel="icon" href="icon-192.png">""")

# ---------- stato per telefono e sincronizzazione ----------
rep("""  piggy: [],         // salvadanai""",
"""  sync: { repo:"", token:"", auto:true, last:null, sha:null },
  push: { on:true, ora:"08:00", sera:true },
  piggy: [],         // salvadanai""")

rep("""  if (!S.bills) S.bills = [];""",
"""  if (!S.sync) S.sync = { repo:"", token:"", auto:true, last:null, sha:null };
  if (!S.push) S.push = { on:true, ora:"08:00", sera:true };
  if (!S.bills) S.bills = [];""")

# ---------- i tre pezzi nuovi: telefono, backup, sincronizzazione ----------
rep("""/* ============================================================
   6. BOOT""",
r'''/* ============================================================
   IL TELEFONO — notifiche, sveglie e timer, quando l'app gira
   dentro l'involucro Android. Nel browser questo pezzo dorme.
   ============================================================ */
const NAT = (typeof window !== "undefined" && window.CoachNativo) ? window.CoachNativo : null;
const inApp = () => { try { return !!(NAT && NAT.disponibile()); } catch(e){ return false; } };

const alle = (d, hhmm) => {
  const [h,m] = (hhmm || "08:00").split(":").map(Number);
  const x = fromIso(d); x.setHours(h, m, 0, 0);
  return x.getTime();
};

/* Tutto quello che merita una notifica nei prossimi sette giorni. */
function avvisiDaProgrammare(){
  const T = today(), ora = Date.now(), out = [];
  const metti = (id, quando, titolo, testo, forte) => {
    if (quando > ora + 60000) out.push({ id, quando, titolo, testo, forte: !!forte });
  };

  for (let i = 0; i < 7; i++){
    const d = addDays(T, i);

    // il riassunto del mattino
    if (S.push.on){
      const acts = planFor(d).length, rem = remindersOn(d).length;
      if (acts || rem){
        const pezzi = [];
        if (acts) pezzi.push(`${acts} ${acts === 1 ? "attività" : "attività"}`);
        if (rem) pezzi.push(`${rem} ${rem === 1 ? "promemoria" : "promemoria"}`);
        metti("giorno-" + d, alle(d, S.push.ora), "La giornata", pezzi.join(" e ") + " da fare oggi.");
      }
    }

    // la chiusura serale
    if (S.push.sera && !S.closes[d])
      metti("chiusura-" + d, alle(d, S.closeAt || "21:00"), "Chiudi la giornata", "Due minuti per dire com'è andata.");

    // la spesa
    if (shopDay(d) && shopLeft())
      metti("spesa-" + d, alle(d, "17:30"), "Spesa", `${shopLeft()} ${shopLeft() === 1 ? "cosa" : "cose"} in lista.`);

    // eventi del giorno, mezz'ora prima
    for (const o of eventsOn(d)){
      if (o.allDay) metti("ev-" + o.id + "-" + d, alle(d, "08:30"), o.label, o.place || "Oggi.", true);
      else metti("ev-" + o.id + "-" + d, alle(d, o.start) - 30*60000, o.label,
                 `Alle ${o.start}${o.place ? " · " + o.place : ""}.`, true);
    }
    // eventi in arrivo, il giorno del preavviso
    for (const o of eventsSoon(d)){
      const dd = daysBetween(d, o.date);
      if (dd === o.warn) metti("evpre-" + o.id, alle(d, "09:00"), o.label,
        `Fra ${dd} ${dd === 1 ? "giorno" : "giorni"}${o.place ? " · " + o.place : ""}.`);
    }

    // la valigia, la sera prima
    for (const t of S.trips){
      const dd = daysBetween(d, t.date);
      const restano = t.items.filter(x => !tripDone(t.id, x.id)).length;
      if (dd === 1 && restano) metti("vg-" + t.id, alle(d, "20:00"), "Valigia · " + t.name,
        `${restano} ${restano === 1 ? "cosa" : "cose"} da mettere: si parte domani.`, true);
    }

    // uscite in arrivo
    for (const b of billsOpen()){
      if (!b.next) continue;
      const soglia = (b.warn >= 0 ? b.warn : S.billWarn);
      if (daysBetween(d, b.next) === soglia)
        metti("bill-" + b.id, alle(d, "09:00"), b.name, `${euro(+b.amount||0)} il ${prettyDate(b.next)}.`);
    }

    // investimenti: cedole e scadenze
    for (const x of investOpen()){
      if (x.nextPay && daysBetween(d, x.nextPay) === 2)
        metti("inv-" + x.id, alle(d, "09:00"), x.name, "Pagamento fra due giorni.");
      if (x.maturity && daysBetween(d, x.maturity) === 30)
        metti("invm-" + x.id, alle(d, "09:00"), x.name, "Scade fra un mese.");
    }

    // frigo: quello che scade quel giorno
    const scad = S.fridge.filter(f => f.exp === d).map(f => f.name);
    if (scad.length) metti("frigo-" + d, alle(d, "10:00"), "Frigo",
      `${scad.slice(0,3).join(", ")} ${scad.length === 1 ? "scade" : "scadono"} oggi.`);
  }

  return out.sort((a,b) => a.quando - b.quando).slice(0, 48);
}

let PUSHTIMER = null;
function riprogrammaAvvisi(){
  if (!inApp()) return;
  clearTimeout(PUSHTIMER);
  PUSHTIMER = setTimeout(() => {
    try {
      NAT.annullaTutte();
      if (isPaused()) return;                       // se sei via, silenzio
      for (const a of avvisiDaProgrammare())
        NAT.programma(a.id, a.titolo, a.testo, a.quando, a.forte);
    } catch(e){}
  }, 1500);
}

function svegliaTelefono(hhmm, etichetta){
  if (!inApp()) return false;
  const [h,m] = (hhmm || "07:00").split(":").map(Number);
  try { NAT.sveglia(h, m, etichetta || "Coach"); return true; } catch(e){ return false; }
}

function timerTelefono(minuti, etichetta){
  if (!inApp()) return false;
  try { NAT.timer(Math.max(60, Math.round(minuti * 60)), etichetta || "Coach"); return true; } catch(e){ return false; }
}

/* ============================================================
   BACKUP — un file con dentro tutto, da tenere da parte
   ============================================================ */
function esportaBackup(){
  const dati = JSON.stringify(S, null, 1);
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([dati], { type:"application/json" }));
  a.download = `coach-${today()}.json`;
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
}

function importaBackup(){
  const inp = document.createElement("input");
  inp.type = "file"; inp.accept = "application/json,.json";
  inp.onchange = () => {
    const f = inp.files && inp.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      try {
        const dati = JSON.parse(r.result);
        if (!dati || typeof dati !== "object" || !dati.v) throw new Error("non è un backup");
        if (!confirm("Rimetto dentro questo backup al posto di quello che c'è adesso?")) return;
        S = dati; migrate(); applyTheme(); runEngine(); save(); render();
        alert("Fatto.");
      } catch(e){ alert("Questo file non è un backup del Coach."); }
    };
    r.readAsText(f);
  };
  inp.click();
}

/* ============================================================
   SINCRONIZZAZIONE — i dati vivono in un file dentro un tuo
   deposito GitHub privato: così due telefoni vedono le stesse cose
   e ogni salvataggio lascia una copia nello storico.
   ============================================================ */
const SYNCFILE = "stato.json";
let SYNCSTATO = "fermo";
let SYNCTIMER = null;

const syncPronto = () => !!(S.sync && S.sync.repo && S.sync.token);

function b64(testo){
  const byte = new TextEncoder().encode(testo);
  let s = "";
  byte.forEach(b => s += String.fromCharCode(b));
  return btoa(s);
}
function unb64(dati){
  const bin = atob(dati.replace(/\n/g, ""));
  const byte = Uint8Array.from(bin, c => c.charCodeAt(0));
  return new TextDecoder().decode(byte);
}

async function ghChiama(metodo, corpo){
  const url = `https://api.github.com/repos/${S.sync.repo}/contents/${SYNCFILE}`;
  const r = await fetch(url, {
    method: metodo,
    headers: {
      "Authorization": "Bearer " + S.sync.token,
      "Accept": "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28"
    },
    body: corpo ? JSON.stringify(corpo) : undefined
  });
  return r;
}

async function syncScarica(){
  const r = await ghChiama("GET");
  if (r.status === 404) return { vuoto:true };
  if (!r.ok) throw new Error("GitHub ha risposto " + r.status);
  const j = await r.json();
  S.sync.sha = j.sha;
  return { dati: JSON.parse(unb64(j.content)), sha: j.sha };
}

async function syncCarica(messaggio){
  const corpo = {
    message: messaggio || ("coach " + new Date().toISOString()),
    content: b64(JSON.stringify(S))
  };
  if (S.sync.sha) corpo.sha = S.sync.sha;
  let r = await ghChiama("PUT", corpo);
  if (r.status === 409 || r.status === 422){          // qualcuno ha scritto prima di noi
    const giu = await syncScarica();
    if (!giu.vuoto && (giu.dati.updatedAt || 0) > (S.updatedAt || 0)){
      S = giu.dati; migrate(); applyTheme(); runEngine(); render();
      return "preso";
    }
    corpo.sha = S.sync.sha;
    r = await ghChiama("PUT", corpo);
  }
  if (!r.ok) throw new Error("GitHub ha risposto " + r.status);
  const j = await r.json();
  S.sync.sha = j.content && j.content.sha;
  return "mandato";
}

async function sincronizza(forzaInvio){
  if (!syncPronto() || SYNCSTATO === "in corso") return;
  SYNCSTATO = "in corso";
  if (TAB === "opzioni") render();
  try {
    const giu = await syncScarica();
    if (!giu.vuoto && !forzaInvio && (giu.dati.updatedAt || 0) > (S.updatedAt || 0) + 500){
      const sha = S.sync.sha, sync = { ...S.sync };
      S = giu.dati; migrate();
      S.sync = sync; S.sync.sha = sha;
      applyTheme(); runEngine();
      S.sync.last = Date.now();
      salvaSolo();
      SYNCSTATO = "preso";
      render();
      return;
    }
    await syncCarica();
    S.sync.last = Date.now();
    salvaSolo();
    SYNCSTATO = "a posto";
  } catch(e){
    SYNCSTATO = "errore: " + (e && e.message ? e.message : e);
  }
  if (TAB === "opzioni") render();
}

// salva senza far ripartire il giro della sincronizzazione
function salvaSolo(){
  try { localStorage.setItem(LS_KEY, JSON.stringify(S)); } catch(e){}
}

function syncDopoIlSalvataggio(){
  if (!syncPronto() || !S.sync.auto) return;
  clearTimeout(SYNCTIMER);
  SYNCTIMER = setTimeout(() => sincronizza(true), 4000);
}

/* ============================================================
   6. BOOT''')

# il salvataggio avvisa anche telefono e sincronizzazione
rep("""let saveTimer = null;
function save(){
  S.updatedAt = Date.now();
  try { localStorage.setItem(LS_KEY, JSON.stringify(S)); } catch(e){}""",
"""let saveTimer = null;
function save(){
  S.updatedAt = Date.now();
  try { localStorage.setItem(LS_KEY, JSON.stringify(S)); } catch(e){}
  if (typeof riprogrammaAvvisi === "function") riprogrammaAvvisi();
  if (typeof syncDopoIlSalvataggio === "function") syncDopoIlSalvataggio();""")

io.open(p,"w",encoding="utf-8").write(s)
print("ok")
