const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
// un mini server per provare la PWA come se fosse online
const tipi = { '.html':'text/html', '.js':'text/javascript', '.png':'image/png', '.webmanifest':'application/manifest+json', '.json':'application/json' };
const srv = http.createServer((req,res) => {
  let f = decodeURIComponent(req.url.split('?')[0]);
  if (f === '/') f = '/index.html';
  const p = path.join(__dirname, f);
  if (!fs.existsSync(p)) { res.writeHead(404); return res.end('no'); }
  res.writeHead(200, {'Content-Type': tipi[path.extname(p)] || 'text/plain'});
  res.end(fs.readFileSync(p));
});
srv.listen(8099, async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ viewport:{width:390,height:900}, deviceScaleFactor:2 });
  const p = await ctx.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push('PAGEERROR: ' + e.message));
  p.on('console', m => { if (m.type()==='error') errs.push('CONSOLE: '+m.text()); });
  await p.goto('http://localhost:8099/');
  await p.waitForTimeout(1500);

  const base = await p.evaluate(() => ({
    manifest: !!document.querySelector('link[rel=manifest]'),
    sw: 'serviceWorker' in navigator,
    swAttivo: !!navigator.serviceWorker.controller,
    inApp: inApp(),
    avvisi: avvisiDaProgrammare().length,
    syncPronto: syncPronto()
  }));

  // dati veri, poi conto gli avvisi
  const avvisi = await p.evaluate(() => {
    const T = today();
    S.activities[0].scheduledFor = T;
    S.reminders.push({ id:'p1', text:'Bidone', body:'', when:{type:'always',days:[0,1,2,3,4,5,6],date:null} });
    addShopItem("Latte",""); S.shop.when = { type:'days', days:[0,1,2,3,4,5,6], date:'' };
    S.oneoffs.push({ id:'e1', label:'Dentista', date:addDays(T,1), endDate:addDays(T,1), start:'15:00', end:'16:00', allDay:false, busy:true, warn:1, place:'Via Roma', note:'', showInMonth:true });
    S.trips.push({ id:'v1', name:'Barcellona', date:addDays(T,2), lead:1, items:[{id:'i1',text:'Documenti'}] });
    S.bills.push({ id:'b1', name:'Netflix', amount:12.99, every:'m', next:addDays(T,3), cat:'Streaming', method:'', warn:3, note:'', closed:null, log:[] });
    S.fridge.push({ id:'f1', name:'Latte', exp:addDays(T,1), qty:'', note:'' });
    save();
    return avvisiDaProgrammare().map(a => `${new Date(a.quando).toLocaleString('it-IT',{weekday:'short',hour:'2-digit',minute:'2-digit'})} · ${a.titolo}: ${a.testo}`);
  });

  // backup: esporta e reimporta
  const backup = await p.evaluate(() => {
    const dati = JSON.parse(JSON.stringify(S));
    const prima = S.shop.items.length;
    S.shop.items = [];
    S = dati; migrate();
    return { prima, dopo: S.shop.items.length, uguali: prima === S.shop.items.length };
  });

  // sincronizzazione senza token: non deve rompere niente
  const sync = await p.evaluate(async () => {
    S.sync.repo = ""; S.sync.token = "";
    await sincronizza();
    return { stato: SYNCSTATO, pronto: syncPronto() };
  });

  await p.evaluate(() => { TAB='opzioni'; render(); });
  await p.waitForTimeout(300);
  await p.screenshot({ path:'/home/claude/pacchetto/impostazioni.png', fullPage:true });

  // ricarica: il service worker deve aver preso il controllo
  await p.reload(); await p.waitForTimeout(1200);
  const dopoReload = await p.evaluate(() => ({ swAttivo: !!navigator.serviceWorker.controller }));
  // e offline?
  await ctx.setOffline(true);
  await p.reload().catch(()=>{});
  await p.waitForTimeout(1200);
  const offline = await p.evaluate(() => ({ titolo: document.querySelector('.datebig')?.textContent || document.title, app: !!document.querySelector('#app') }));
  await ctx.setOffline(false);

  console.log('base:', JSON.stringify(base));
  console.log('avvisi programmati:', avvisi.length); avvisi.slice(0,8).forEach(x => console.log('   ' + x));
  console.log('backup:', JSON.stringify(backup), '| sync senza token:', JSON.stringify(sync));
  console.log('dopo reload:', JSON.stringify(dopoReload), '| offline:', JSON.stringify(offline));
  console.log('ERRORI:', errs.length ? errs : 'nessuno');
  await b.close(); srv.close();
});
