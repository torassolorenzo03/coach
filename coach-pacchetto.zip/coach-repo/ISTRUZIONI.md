# Coach — da pagina di Claude a vera app Android

Dentro questa cartella c'è tutto. Tu devi fare solo i passaggi qui sotto: non serve
installare niente sul computer, compila GitHub per te.

---

## 1. Il deposito dell'app (5 minuti)

1. Su github.com, in alto a destra: **+ → New repository**
2. Nome: `coach` — lascialo **Public** — **Create repository**
3. Nella pagina che si apre: **uploading an existing file**
4. Trascina dentro **tutto il contenuto di questa cartella** (le cartelle `docs`,
   `android`, `.github` e questo file). Aspetta che finisca di caricare.
5. In fondo: **Commit changes**

> Se la cartella `.github` non si carica (certi computer nascondono le cartelle
> che iniziano col punto), vedi in fondo, al punto "Se manca .github".

## 2. Accendere il sito (2 minuti)

1. Nel deposito: **Settings** (in alto) → **Pages** (colonna a sinistra)
2. Source: **Deploy from a branch**
3. Branch: **main**, cartella: **/docs** → **Save**
4. Aspetta un minuto e ricarica: compare l'indirizzo, tipo
   `https://TUONOME.github.io/coach/`
5. **Segnatelo**: serve al passo 4.

Apri quell'indirizzo dal telefono: è già la tua app. Menu di Chrome →
**Aggiungi a schermata Home** e diventa un'icona come le altre.

## 3. Portare dentro i tuoi dati (1 minuto)

1. Apri l'app **dentro Claude** (quella che usi adesso) → Impostazioni → **Esporta**
   → **Copia il testo** (dentro Claude i download sono bloccati, quindi si copia)
2. Apri il **sito nuovo** dal computer o dal telefono → Impostazioni → **Importa**
   → incolla nel riquadro → **Rimetti dentro**

Dal sito in poi il tasto **Scarica il file** funziona: quello è il backup da tenere
da parte ogni tanto.

Da qui in poi il sito è la tua app vera. Quella dentro Claude resta com'è.

## 4. L'APK per Android (10 minuti, quasi tutti di attesa)

1. Nel deposito apri `android/app/src/main/res/values/strings.xml`
   (matita in alto a destra per modificare)
2. Sostituisci `https://ESEMPIO.github.io/coach/` con **il tuo indirizzo** del passo 2.
   Attento a lasciare la barra `/` finale. → **Commit changes**
3. Vai su **Actions** (in alto). Se chiede di abilitarle, conferma.
4. A sinistra: **Costruisci l'APK** → a destra **Run workflow** → **Run workflow**
5. Dopo 3-5 minuti il pallino diventa verde. Entra nel lavoro finito e in fondo,
   sotto **Artifacts**, scarica **Coach-APK**.
6. Sul telefono: apri il file scaricato, estrai `app-debug.apk`, installalo.
   Android chiederà di permettere le installazioni da quella fonte: è normale.

## 5. I permessi sul telefono (1 minuto)

Apri l'app e poi Impostazioni dentro l'app:

- Al primo avvio Android chiede il permesso per le **notifiche**: dai sì.
- **Permesso per gli orari esatti** → Apri → concedi. Senza, le notifiche possono
  arrivare con qualche minuto di ritardo.
- Consiglio: nelle impostazioni Android dell'app, batteria → **senza restrizioni**,
  altrimenti il telefono può addormentare le notifiche.

## 6. La sincronizzazione fra dispositivi (5 minuti)

Serve un secondo deposito, **privato**, dove vivono i tuoi dati.

1. Su GitHub: **+ → New repository**, nome `coach-dati`, scegli **Private**,
   spunta **Add a README file** → Create.
2. Ora il token: clicca la tua foto in alto a destra → **Settings** →
   in fondo a sinistra **Developer settings** → **Personal access tokens** →
   **Fine-grained tokens** → **Generate new token**
   - Token name: `coach`
   - Expiration: scegli **No expiration** (o un anno)
   - Repository access: **Only select repositories** → scegli **coach-dati**
   - Permissions → Repository permissions → **Contents**: metti **Read and write**
   - In fondo: **Generate token** → **copia** il codice che compare
     (lo vedi una volta sola)
3. Nell'app: Impostazioni → Sincronizzazione
   - Deposito: `TUONOME/coach-dati`
   - Token: incolla
   - **Salva e sincronizza**

Da quel momento ogni modifica finisce lì dentro entro pochi secondi, e ogni
dispositivo dove metti gli stessi due dati vede le stesse cose. In più ti ritrovi
lo storico completo: dentro `coach-dati` ogni salvataggio è una versione.

---

## Come si aggiorna, dopo

- **Cambio qualcosa nell'app**: ti do il nuovo `index.html`, tu lo carichi in `docs`
  (Add file → Upload files, stesso nome, sovrascrive). L'app sul telefono si
  aggiorna da sola alla riapertura. **Niente APK da rifare.**
- **Cambio qualcosa di Android** (notifiche, sveglie, permessi): allora sì, rilanci
  il workflow dal punto 4 e reinstalli l'APK.

## Se manca .github

Nel deposito: **Add file → Create new file**. Come nome del file scrivi
`.github/workflows/apk.yml` (le barre creano le cartelle da sole), incolla dentro
il contenuto del file `apk.yml` che trovi in questa cartella, e salva.

## Se qualcosa non va

- Il sito dice 404: aspetta due minuti, Pages ci mette un po' la prima volta.
- Il workflow diventa rosso: aprilo, copia le ultime righe rosse e mandamele.
- L'app si apre bianca: quasi sempre è l'indirizzo nel file `strings.xml`,
  controlla che sia identico a quello del sito e con la barra finale.
