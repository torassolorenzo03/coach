package it.coach.app;

import android.app.Activity;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * La giornata in breve (mattino) e la chiusura serale (sera) a schermo intero,
 * anche a telefono bloccato. Da qui si apre Coach sulla giornata o sulla chiusura;
 * la sera si può rimandare di mezz'ora.
 */
public class GiornataActivity extends Activity {

    private static WeakReference<GiornataActivity> aperta = new WeakReference<>(null);
    private String id, titolo, testo, tipo;
    private String azione, etichetta;  // gli schermi con un tasto loro (dalla 2.5): tipo "az:azione:etichetta"

    /** Se la rimandi dalla notifica, si chiude anche lo schermo (solo se mostra proprio quella). */
    static void chiudiSeAperta(String id) {
        final GiornataActivity a = aperta.get();
        if (a == null || (id != null && a.id != null && !id.equals(a.id))) return;
        a.runOnUiThread(new Runnable() { @Override public void run() { a.finish(); } });
    }

    @Override
    protected void onCreate(Bundle stato) {
        super.onCreate(stato);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        aperta = new WeakReference<>(this);
        leggi(getIntent());
        disegna();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        leggi(i);
        disegna();
    }

    @Override
    protected void onDestroy() {
        if (aperta.get() == this) aperta = new WeakReference<>(null);
        super.onDestroy();
    }

    private void leggi(Intent i) {
        id = i == null ? null : i.getStringExtra("id");
        titolo = i == null ? null : i.getStringExtra("titolo");
        testo = i == null ? null : i.getStringExtra("testo");
        tipo = i == null ? null : i.getStringExtra("tipo");
        if (tipo == null) tipo = "mattino";
        azione = null; etichetta = null;
        if (tipo.startsWith("az:")) {
            String[] p = tipo.split(":", 3);
            azione = p.length > 1 && !p[1].isEmpty() ? p[1] : "breve";
            etichetta = p.length > 2 && !p[2].isEmpty() ? p[2] : "Apri Coach";
        }
        if (titolo == null) titolo = sera() ? "Chiudi la giornata" : "La giornata in breve";
        if (testo == null) testo = "";
    }

    private boolean sera() { return "sera".equals(tipo); }
    private boolean suo() { return azione != null; }

    /** Il saluto secondo l'ora, per gli schermi che possono arrivare in ogni momento. */
    private static String saluto() {
        int h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        return h < 12 ? "BUONGIORNO" : h < 18 ? "BUON POMERIGGIO" : "BUONASERA";
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView scritta(String s, int sp, int colore, boolean grassetto) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(colore);
        if (grassetto) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button tasto(String s, int sfondo, int colore, int bordo) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(18);
        b.setTextColor(colore);
        GradientDrawable g = new GradientDrawable();
        g.setColor(sfondo);
        g.setCornerRadius(dp(16));
        if (bordo != 0) g.setStroke(dp(1), bordo);
        b.setBackground(g);
        return b;
    }

    /** Toglie la notifica di questa schermata. */
    private void togliNotifica() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null && id != null) nm.cancel(id.hashCode());
    }

    /** Apre Coach sulla giornata ("breve") o sulla chiusura ("chiudi"): prima si sblocca il telefono. */
    private void apriCoach(String azione) {
        togliNotifica();
        final Intent i = new Intent(this, MainActivity.class)
                .putExtra("azione", azione)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        KeyguardManager km = getSystemService(KeyguardManager.class);
        if (km != null && km.isKeyguardLocked()) {
            km.requestDismissKeyguard(this, new KeyguardManager.KeyguardDismissCallback() {
                @Override public void onDismissSucceeded() { startActivity(i); finish(); }
            });
        } else {
            startActivity(i);
            finish();
        }
    }

    private void disegna() {
        boolean scuro = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        int sfondo = scuro ? 0xFF141A18 : 0xFFE6E8E3;
        int inchiostro = scuro ? 0xFFE8EAE6 : 0xFF18211E;
        int tenue = scuro ? 0xFF9AA49F : 0xFF5C6862;
        int accento = scuro ? 0xFF3FA090 : 0xFF1F6F63;
        int suAccento = scuro ? 0xFF0B1211 : 0xFFFFFFFF;
        int linea = scuro ? 0xFF2F3A37 : 0xFFC8CEC7;

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackgroundColor(sfondo);
        l.setPadding(dp(26), dp(44), dp(26), dp(30));

        l.addView(scritta(sera() ? "BUONASERA" : suo() ? saluto() : "BUONGIORNO", 13, accento, true));
        l.addView(scritta(new SimpleDateFormat("EEEE d MMMM · H:mm", Locale.ITALIAN).format(new Date()), 15, tenue, false));
        TextView cosa = scritta(titolo, 30, inchiostro, true);
        cosa.setPadding(0, dp(14), 0, dp(10));
        l.addView(cosa);

        // il testo può essere lungo (la giornata in breve): scorre, i tasti restano in fondo
        ScrollView scorre = new ScrollView(this);
        TextView corpo = scritta(testo, 18, inchiostro, false);
        corpo.setLineSpacing(dp(4), 1f);
        scorre.addView(corpo);
        l.addView(scorre, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(60));
        lp.topMargin = dp(18);
        Button principale = tasto(suo() ? etichetta : sera() ? "Chiudi la giornata" : "Apri la giornata", accento, suAccento, 0);
        principale.setOnClickListener(v -> apriCoach(suo() ? azione : sera() ? "chiudi" : "breve"));
        l.addView(principale, lp);

        LinearLayout riga = new LinearLayout(this);
        riga.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lr = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        lr.topMargin = dp(10);
        if (sera() || suo()) {
            Button dopo = tasto("Fra " + Avvisatore.MINUTI_RIMANDA + " minuti", sfondo, inchiostro, linea);
            dopo.setOnClickListener(v -> { Avvisatore.rimanda(this, id, titolo, testo, tipo); finish(); });
            LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
            a.rightMargin = dp(10);
            riga.addView(dopo, a);
        }
        Button chiudi = tasto(sera() ? "Non stasera" : "Più tardi", sfondo, inchiostro, linea);
        chiudi.setOnClickListener(v -> { togliNotifica(); finish(); });
        riga.addView(chiudi, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f));
        l.addView(riga, lr);

        setContentView(l);
    }
}
