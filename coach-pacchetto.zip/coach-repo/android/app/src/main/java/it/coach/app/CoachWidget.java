package it.coach.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Il widget della schermata Home: la data, quanto hai fatto, cosa c'è adesso
 * e cosa viene dopo, più il tasto + per aggiungere al volo.
 * La pagina gli passa la giornata di oggi e di domani; da lì il widget si
 * aggiorna da solo quando finisce una cosa o ne comincia un'altra.
 */
public class CoachWidget extends AppWidgetProvider {

    static final String PREF = "coach_widget";
    static final String TICK = "it.coach.app.WIDGET_TICK";

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        disegna(c, m, ids);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (i != null && TICK.equals(i.getAction())) aggiornaTutti(c);
    }

    @Override
    public void onDisabled(Context c) {
        // tolto l'ultimo widget: niente più aggiornamenti programmati
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am != null) am.cancel(tick(c));
    }

    static void aggiornaTutti(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        if (m == null) return;
        int[] ids = m.getAppWidgetIds(new ComponentName(c, CoachWidget.class));
        if (ids != null && ids.length > 0) disegna(c, m, ids);
    }

    private static PendingIntent tick(Context c) {
        Intent i = new Intent(c, CoachWidget.class).setAction(TICK);
        return PendingIntent.getBroadcast(c, 7001, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static String ore(long ms) {
        return new SimpleDateFormat("H:mm", Locale.ITALIAN).format(new Date(ms));
    }

    private static String giorno(long ms) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(ms));
    }

    static void disegna(Context c, AppWidgetManager m, int[] ids) {
        long adesso = System.currentTimeMillis();
        String oggi = giorno(adesso);
        String titolo = new SimpleDateFormat("EEEE d MMMM", Locale.ITALIAN).format(new Date(adesso));
        if (!titolo.isEmpty()) titolo = titolo.substring(0, 1).toUpperCase(Locale.ITALIAN) + titolo.substring(1);

        int pct = -1, daFare = 0, decidere = 0;
        boolean fresco = false;
        JSONObject ora = null, dopo = null;
        long prossimoCambio = Long.MAX_VALUE;

        try {
            String raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("dati", "");
            if (raw != null && !raw.isEmpty()) {
                JSONObject d = new JSONObject(raw);
                fresco = oggi.equals(d.optString("giorno"));
                if (fresco) {
                    pct = d.optInt("pct", -1);
                    daFare = d.optInt("daFare", 0);
                    decidere = d.optInt("decidere", 0);
                }
                JSONArray voci = d.optJSONArray("voci");
                if (voci != null) {
                    for (int k = 0; k < voci.length(); k++) {
                        JSONObject x = voci.getJSONObject(k);
                        long s = x.optLong("s"), e = x.optLong("e");
                        if (s <= adesso && adesso < e) {
                            // fra due cose insieme vince l'impegno, non l'attività
                            if (ora == null || ("att".equals(ora.optString("k")) && !"att".equals(x.optString("k")))) ora = x;
                            prossimoCambio = Math.min(prossimoCambio, e);
                        }
                        if (s > adesso) {
                            if (dopo == null || s < dopo.optLong("s")) dopo = x;
                            prossimoCambio = Math.min(prossimoCambio, s);
                        }
                    }
                }
            }
        } catch (Exception ignored) { }

        RemoteViews r = new RemoteViews(c.getPackageName(), R.layout.widget);
        r.setTextViewText(R.id.w_data, titolo);
        if (pct >= 0) {
            r.setTextViewText(R.id.w_pct, pct + "%");
            r.setProgressBar(R.id.w_barra, 100, pct, false);
            r.setViewVisibility(R.id.w_barra, View.VISIBLE);
        } else {
            r.setTextViewText(R.id.w_pct, "");
            r.setViewVisibility(R.id.w_barra, View.INVISIBLE);
        }

        if (ora != null) {
            r.setTextViewText(R.id.w_adesso, ora.optString("t"));
            r.setTextViewText(R.id.w_adesso_sub, "fino alle " + ore(ora.optLong("e")));
        } else {
            r.setTextViewText(R.id.w_adesso, "Libero");
            r.setTextViewText(R.id.w_adesso_sub, dopo != null && oggi.equals(giorno(dopo.optLong("s")))
                    ? "fino alle " + ore(dopo.optLong("s")) : "per il resto della giornata");
        }
        if (dopo != null) {
            boolean domani = !oggi.equals(giorno(dopo.optLong("s")));
            r.setTextViewText(R.id.w_poi, dopo.optString("t"));
            r.setTextViewText(R.id.w_poi_sub, (domani ? "domani alle " : "alle ") + ore(dopo.optLong("s")));
        } else {
            r.setTextViewText(R.id.w_poi, "Niente");
            r.setTextViewText(R.id.w_poi_sub, "in programma");
        }

        String riga;
        if (!fresco) riga = "Apri Coach per aggiornare la giornata";
        else if (daFare == 0 && decidere == 0) riga = "Per oggi è tutto fatto";
        else riga = daFare + (daFare == 1 ? " cosa da fare" : " cose da fare")
                + (decidere > 0 ? " · " + decidere + " da decidere" : "");
        r.setTextViewText(R.id.w_riga, riga);

        Intent apri = new Intent(c, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        r.setOnClickPendingIntent(R.id.w_tutto, PendingIntent.getActivity(c, 7002, apri,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        Intent piu = new Intent(c, MainActivity.class)
                .setAction("it.coach.app.AGGIUNGI")
                .putExtra("azione", "aggiungi")
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        r.setOnClickPendingIntent(R.id.w_piu, PendingIntent.getActivity(c, 7003, piu,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));

        m.updateAppWidget(ids, r);

        // il prossimo ridisegno: quando cambia qualcosa, al più tardi a mezzanotte
        Calendar mezzanotte = Calendar.getInstance();
        mezzanotte.add(Calendar.DAY_OF_MONTH, 1);
        mezzanotte.set(Calendar.HOUR_OF_DAY, 0);
        mezzanotte.set(Calendar.MINUTE, 1);
        mezzanotte.set(Calendar.SECOND, 0);
        long quando = Math.min(prossimoCambio, mezzanotte.getTimeInMillis()) + 20000;
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am != null) {
            am.cancel(tick(c));
            am.setAndAllowWhileIdle(AlarmManager.RTC, quando, tick(c));
        }
    }
}
