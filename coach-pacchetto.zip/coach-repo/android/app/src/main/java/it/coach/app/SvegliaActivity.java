package it.coach.app;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * La sveglia a schermo intero: si apre anche a telefono bloccato.
 * Il suono è quello della notifica (si ripete finché non la fermi):
 * "Ferma" lo spegne, "Fra 5 minuti" la rimanda.
 */
public class SvegliaActivity extends Activity {

    private static WeakReference<SvegliaActivity> aperta = new WeakReference<>(null);
    private String id, titolo, testo;

    /** Se la fermi dalla notifica, si chiude anche lo schermo (solo se mostra proprio quella sveglia). */
    static void chiudiSeAperta(String id) {
        final SvegliaActivity a = aperta.get();
        if (a == null || (id != null && a.id != null && !id.equals(a.id))) return;
        a.runOnUiThread(new Runnable() { @Override public void run() { a.finish(); } });
    }

    @Override
    protected void onCreate(Bundle stato) {
        super.onCreate(stato);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        aperta = new WeakReference<>(this);
        leggi(getIntent());
        disegna();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        leggi(i);
        disegna();
    }

    @Override
    protected void onDestroy() {
        if (aperta.get() == this) aperta = new WeakReference<>(null);
        super.onDestroy();
    }

    private void leggi(Intent i) {
        id = i == null ? null : i.getStringExtra("id");
        titolo = i == null ? null : i.getStringExtra("titolo");
        testo = i == null ? null : i.getStringExtra("testo");
        if (titolo == null) titolo = "Sveglia";
        if (testo == null) testo = "";
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView scritta(String s, int sp, int colore, boolean grassetto) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(colore);
        t.setGravity(Gravity.CENTER);
        if (grassetto) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button tasto(String s, int sfondo, int colore, int bordo) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(19);
        b.setTextColor(colore);
        GradientDrawable g = new GradientDrawable();
        g.setColor(sfondo);
        g.setCornerRadius(dp(16));
        if (bordo != 0) g.setStroke(dp(1), bordo);
        b.setBackground(g);
        return b;
    }

    private void disegna() {
        boolean scuro = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        int sfondo = scuro ? 0xFF141A18 : 0xFFE6E8E3;
        int inchiostro = scuro ? 0xFFE8EAE6 : 0xFF18211E;
        int tenue = scuro ? 0xFF9AA49F : 0xFF5C6862;
        int accento = scuro ? 0xFF3FA090 : 0xFF1F6F63;
        int linea = scuro ? 0xFF273331 : 0xFFDDE0DA;

        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(sfondo);
        l.setPadding(dp(28), dp(48), dp(28), dp(40));

        l.addView(scritta("SVEGLIA", 13, accento, true));
        TextView ora = scritta(new SimpleDateFormat("H:mm", Locale.ITALIAN).format(new Date()), 72, inchiostro, true);
        l.addView(ora);
        TextView cosa = scritta(titolo, 28, inchiostro, true);
        cosa.setPadding(0, dp(18), 0, dp(6));
        l.addView(cosa);
        if (!testo.isEmpty()) l.addView(scritta(testo, 17, tenue, false));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(64));
        lp.topMargin = dp(44);
        Button ferma = tasto("Ferma", accento, 0xFFFFFFFF, 0);
        ferma.setOnClickListener(v -> { Avvisatore.ferma(this, id); finish(); });
        l.addView(ferma, lp);

        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58));
        lp2.topMargin = dp(12);
        Button dopo = tasto("Fra " + Avvisatore.MINUTI_POSTICIPA + " minuti", sfondo, inchiostro, linea);
        dopo.setOnClickListener(v -> { Avvisatore.posticipa(this, id, titolo, testo); finish(); });
        l.addView(dopo, lp2);

        setContentView(l);
    }
}
