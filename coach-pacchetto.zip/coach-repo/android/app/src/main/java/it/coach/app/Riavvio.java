package it.coach.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Dopo un riavvio del telefono le sveglie programmate vanno rimesse. */
public class Riavvio extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        Avvisi.creaCanali(c);
        Ponte.riprogrammaTutte(c);
    }
}
