package it.coach.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;

/** I canali: i promemoria normali, le cose che devono svegliarti, e le sveglie vere. */
public class Avvisi {
    public static final String CANALE = "coach_promemoria";
    public static final String CANALE_FORTE = "coach_importanti";
    public static final String CANALE_SVEGLIA = "coach_sveglie";

    public static void creaCanali(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;

        NotificationChannel normale = new NotificationChannel(
                CANALE, "Promemoria", NotificationManager.IMPORTANCE_DEFAULT);
        normale.setDescription("Le cose della giornata: attività, spesa, scadenze");
        nm.createNotificationChannel(normale);

        NotificationChannel forte = new NotificationChannel(
                CANALE_FORTE, "Importanti", NotificationManager.IMPORTANCE_HIGH);
        forte.setDescription("Quello che non deve sfuggirti: pagamenti, partenze");
        forte.enableVibration(true);
        nm.createNotificationChannel(forte);

        // la sveglia: il suono delle sveglie del telefono, sul volume delle sveglie
        NotificationChannel sveglia = new NotificationChannel(
                CANALE_SVEGLIA, "Sveglie", NotificationManager.IMPORTANCE_HIGH);
        sveglia.setDescription("Le sveglie degli eventi: suonano finché non le fermi");
        Uri suono = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (suono == null) suono = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        sveglia.setSound(suono, new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build());
        sveglia.enableVibration(true);
        sveglia.setVibrationPattern(new long[] { 0, 800, 600, 800, 600 });
        sveglia.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(sveglia);
    }
}
