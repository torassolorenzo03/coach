package it.coach.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;

/** I due canali: i promemoria normali e le cose che devono svegliarti. */
public class Avvisi {
    public static final String CANALE = "coach_promemoria";
    public static final String CANALE_FORTE = "coach_importanti";

    public static void creaCanali(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;

        NotificationChannel normale = new NotificationChannel(
                CANALE, "Promemoria", NotificationManager.IMPORTANCE_DEFAULT);
        normale.setDescription("Le cose della giornata: attività, spesa, scadenze");
        nm.createNotificationChannel(normale);

        NotificationChannel forte = new NotificationChannel(
                CANALE_FORTE, "Importanti", NotificationManager.IMPORTANCE_HIGH);
        forte.setDescription("Quello che non deve sfuggirti: pagamenti, partenze");
        forte.enableVibration(true);
        nm.createNotificationChannel(forte);
    }
}
