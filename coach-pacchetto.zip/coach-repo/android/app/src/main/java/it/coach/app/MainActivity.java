package it.coach.app;

import android.Manifest;
import android.app.NotificationManager;
import android.content.ClipData;
import android.database.Cursor;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.speech.RecognizerIntent;
import android.view.KeyEvent;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

import java.util.ArrayList;

/** L'app non è altro che una finestra sul sito, più un ponte verso il telefono. */
public class MainActivity extends AppCompatActivity {

    private WebView vista;
    private ActivityResultLauncher<String> chiediNotifiche;
    private ActivityResultLauncher<String> chiediCalendario;
    private ActivityResultLauncher<Intent> scegliFile;
    private ActivityResultLauncher<Intent> dettatura;
    private ActivityResultLauncher<Intent> contatto;
    private ValueCallback<Uri[]> attesaFile;
    private String azioneInAttesa;     // dal widget: cosa fare quando la pagina è pronta
    private boolean paginaPronta = false;

    @Override
    protected void onCreate(Bundle stato) {
        super.onCreate(stato);

        chiediNotifiche = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), ok -> { });

        // il permesso del calendario: quando rispondi, la pagina lo viene a sapere
        chiediCalendario = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                ok -> avvisaPagina("calendario", ok ? "si" : "no"));

        // il selettore dei file: senza questo, i campi "scegli un file" non aprono niente
        scegliFile = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                this::fileScelti);

        // la dettatura: il riconoscimento vocale del telefono, il testo torna alla pagina
        dettatura = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                r -> {
                    Intent dati = r.getData();
                    if (r.getResultCode() == RESULT_OK && dati != null) {
                        ArrayList<String> frasi = dati.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                        if (frasi != null && !frasi.isEmpty()) { avvisaPaginaTesto("dettato", frasi.get(0)); return; }
                    }
                    avvisaPaginaTesto("dettato", "");
                });

        // un contatto dalla rubrica: nome e numero tornano alla pagina. Nessun permesso: lo scegli tu.
        contatto = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                r -> {
                    Intent dati = r.getData();
                    if (r.getResultCode() == RESULT_OK && dati != null && dati.getData() != null)
                        avvisaPaginaTesto("contatto", leggiContatto(dati.getData()));
                    else avvisaPaginaTesto("contatto", "");
                });

        // aperta dal + del widget o dalla mattina e dalla sera (non quando Android la ricrea da sé: lì l'azione è già stata fatta)
        if (stato == null) azioneInAttesa = azioneDa(getIntent());
        togliNotifica(getIntent());

        vista = new WebView(this);
        setContentView(vista);

        WebSettings s = vista.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportMultipleWindows(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(vista, true);

        vista.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb,
                                             WebChromeClient.FileChooserParams p) {
                if (attesaFile != null) attesaFile.onReceiveValue(null);
                attesaFile = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("*/*");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                if (p != null && p.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE)
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    scegliFile.launch(Intent.createChooser(i, "Scegli un file"));
                } catch (Exception e) {
                    attesaFile = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        vista.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView w, String indirizzo) {
                paginaPronta = true;
                if (azioneInAttesa != null) { avvisaPagina("azione", azioneInAttesa); azioneInAttesa = null; }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest richiesta) {
                Uri u = richiesta.getUrl();
                String mio = getString(R.string.indirizzo_app);
                // i link verso fuori si aprono nel browser, il resto resta dentro
                if (u.toString().startsWith(mio)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) { return false; }
                return true;
            }
        });

        vista.addJavascriptInterface(new Ponte(this), "CoachNativo");
        Avvisi.creaCanali(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            chiediNotifiche.launch(Manifest.permission.POST_NOTIFICATIONS);
        }

        vista.loadUrl(getString(R.string.indirizzo_app));
    }

    private void fileScelti(ActivityResult r) {
        if (attesaFile == null) return;
        Uri[] scelti = null;
        Intent dati = r.getData();
        if (r.getResultCode() == RESULT_OK && dati != null) {
            ArrayList<Uri> lista = new ArrayList<>();
            ClipData clip = dati.getClipData();
            if (clip != null) {
                for (int k = 0; k < clip.getItemCount(); k++) {
                    Uri u = clip.getItemAt(k).getUri();
                    if (u != null) lista.add(u);
                }
            } else if (dati.getData() != null) {
                lista.add(dati.getData());
            }
            if (!lista.isEmpty()) scelti = lista.toArray(new Uri[0]);
        }
        attesaFile.onReceiveValue(scelti);
        attesaFile = null;
    }

    /** Chiesto dalla pagina tramite il ponte. */
    void domandaCalendario() {
        runOnUiThread(() -> {
            try { chiediCalendario.launch(Manifest.permission.READ_CALENDAR); }
            catch (Exception e) { avvisaPagina("calendario", "no"); }
        });
    }

    /** Racconta alla pagina qualcosa che è successo sul telefono. */
    void avvisaPagina(String cosa, String valore) {
        if (vista == null) return;
        final String js = "try{window.dalTelefono&&window.dalTelefono('" + cosa + "','" + valore + "')}catch(e){}";
        vista.post(() -> vista.evaluateJavascript(js, null));
    }

    /** Come avvisaPagina, ma per un testo qualsiasi (la dettatura): va messo fra virgolette. */
    void avvisaPaginaTesto(String cosa, String testo) {
        if (vista == null) return;
        final String js = "try{window.dalTelefono&&window.dalTelefono(" + JSONObject.quote(cosa) + "," + JSONObject.quote(testo == null ? "" : testo) + ")}catch(e){}";
        vista.post(() -> vista.evaluateJavascript(js, null));
    }

    /** Chiesto dalla pagina: apre il riconoscimento vocale del telefono. */
    void avviaDettatura() {
        runOnUiThread(() -> {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "it-IT")
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "Dimmi cosa segnare");
            try { dettatura.launch(i); }
            catch (Exception e) { avvisaPagina("dettato-errore", "nodisp"); }
        });
    }

    private static String azioneDa(Intent i) {
        return i == null ? null : i.getStringExtra("azione");
    }

    /** Aperta da un tasto di una notifica: quella notifica non serve più. */
    private void togliNotifica(Intent i) {
        int n = i == null ? 0 : i.getIntExtra("notifica", 0);
        if (n == 0) return;
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(n);
    }

    /** Chiesto dalla pagina: apre la rubrica per scegliere un contatto col suo numero. */
    void scegliContatto() {
        runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_PICK).setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE);
            try { contatto.launch(i); }
            catch (Exception e) { avvisaPaginaTesto("contatto", ""); }
        });
    }

    /** Nome e numero del contatto scelto, come {"nome":…, "numero":…}. */
    private String leggiContatto(Uri u) {
        String[] campi = { ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER };
        Cursor c = null;
        try {
            c = getContentResolver().query(u, campi, null, null, null);
            if (c != null && c.moveToFirst()) {
                JSONObject o = new JSONObject();
                o.put("nome", c.getString(0) == null ? "" : c.getString(0));
                o.put("numero", c.getString(1) == null ? "" : c.getString(1));
                return o.toString();
            }
        } catch (Exception ignored) {
        } finally { if (c != null) c.close(); }
        return "";
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        togliNotifica(i);
        String az = azioneDa(i);
        if (az == null) return;
        if (paginaPronta) avvisaPagina("azione", az); else azioneInAttesa = az;
    }

    /** La risposta a una richiesta fatta dal telefono per conto della pagina. */
    void rispondi(String id, String json) {
        if (vista == null) return;
        final String js = "try{window.dalRete&&window.dalRete(" + JSONObject.quote(id) + "," + JSONObject.quote(json) + ")}catch(e){}";
        vista.post(() -> vista.evaluateJavascript(js, null));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // tornando nell'app il calendario potrebbe essere cambiato: la pagina lo rilegge
        avvisaPagina("ripreso", "1");
    }

    @Override
    public boolean onKeyDown(int codice, KeyEvent evento) {
        if (codice == KeyEvent.KEYCODE_BACK && vista.canGoBack()) {
            vista.goBack();
            return true;
        }
        return super.onKeyDown(codice, evento);
    }
}
