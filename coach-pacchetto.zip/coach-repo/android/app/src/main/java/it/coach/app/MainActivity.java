package it.coach.app;

import android.Manifest;
import android.content.ClipData;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

/** L'app non è altro che una finestra sul sito, più un ponte verso il telefono. */
public class MainActivity extends AppCompatActivity {

    private WebView vista;
    private ActivityResultLauncher<String> chiediNotifiche;
    private ActivityResultLauncher<String> chiediCalendario;
    private ActivityResultLauncher<Intent> scegliFile;
    private ValueCallback<Uri[]> attesaFile;

    @Override
    protected void onCreate(Bundle stato) {
        super.onCreate(stato);

        chiediNotifiche = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), ok -> { });

        // il permesso del calendario: quando rispondi, la pagina lo viene a sapere
        chiediCalendario = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                ok -> avvisaPagina("calendario", ok ? "si" : "no"));

        // il selettore dei file: senza questo, i campi "scegli un file" non aprono niente
        scegliFile = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                this::fileScelti);

        vista = new WebView(this);
        setContentView(vista);

        WebSettings s = vista.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportMultipleWindows(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(vista, true);

        vista.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb,
                                             WebChromeClient.FileChooserParams p) {
                if (attesaFile != null) attesaFile.onReceiveValue(null);
                attesaFile = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("*/*");
                i.addCategory(Intent.CATEGORY_OPENABLE);
                if (p != null && p.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE)
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    scegliFile.launch(Intent.createChooser(i, "Scegli un file"));
                } catch (Exception e) {
                    attesaFile = null;
                    cb.onReceiveValue(null);
                    return false;
                }
                return true;
            }
        });

        vista.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest richiesta) {
                Uri u = richiesta.getUrl();
                String mio = getString(R.string.indirizzo_app);
                // i link verso fuori si aprono nel browser, il resto resta dentro
                if (u.toString().startsWith(mio)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) { return false; }
                return true;
            }
        });

        vista.addJavascriptInterface(new Ponte(this), "CoachNativo");
        Avvisi.creaCanali(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            chiediNotifiche.launch(Manifest.permission.POST_NOTIFICATIONS);
        }

        vista.loadUrl(getString(R.string.indirizzo_app));
    }

    private void fileScelti(ActivityResult r) {
        if (attesaFile == null) return;
        Uri[] scelti = null;
        Intent dati = r.getData();
        if (r.getResultCode() == RESULT_OK && dati != null) {
            ArrayList<Uri> lista = new ArrayList<>();
            ClipData clip = dati.getClipData();
            if (clip != null) {
                for (int k = 0; k < clip.getItemCount(); k++) {
                    Uri u = clip.getItemAt(k).getUri();
                    if (u != null) lista.add(u);
                }
            } else if (dati.getData() != null) {
                lista.add(dati.getData());
            }
            if (!lista.isEmpty()) scelti = lista.toArray(new Uri[0]);
        }
        attesaFile.onReceiveValue(scelti);
        attesaFile = null;
    }

    /** Chiesto dalla pagina tramite il ponte. */
    void domandaCalendario() {
        runOnUiThread(() -> {
            try { chiediCalendario.launch(Manifest.permission.READ_CALENDAR); }
            catch (Exception e) { avvisaPagina("calendario", "no"); }
        });
    }

    /** Racconta alla pagina qualcosa che è successo sul telefono. */
    void avvisaPagina(String cosa, String valore) {
        if (vista == null) return;
        final String js = "try{window.dalTelefono&&window.dalTelefono('" + cosa + "','" + valore + "')}catch(e){}";
        vista.post(() -> vista.evaluateJavascript(js, null));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // tornando nell'app il calendario potrebbe essere cambiato: la pagina lo rilegge
        avvisaPagina("ripreso", "1");
    }

    @Override
    public boolean onKeyDown(int codice, KeyEvent evento) {
        if (codice == KeyEvent.KEYCODE_BACK && vista.canGoBack()) {
            vista.goBack();
            return true;
        }
        return super.onKeyDown(codice, evento);
    }
}
