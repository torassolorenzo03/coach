package it.coach.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/** L'app non è altro che una finestra sul sito, più un ponte verso il telefono. */
public class MainActivity extends AppCompatActivity {

    private WebView vista;
    private ActivityResultLauncher<String> chiediNotifiche;

    @Override
    protected void onCreate(Bundle stato) {
        super.onCreate(stato);

        chiediNotifiche = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), ok -> { });

        vista = new WebView(this);
        setContentView(vista);

        WebSettings s = vista.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportMultipleWindows(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(vista, true);

        vista.setWebChromeClient(new WebChromeClient());
        vista.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest richiesta) {
                Uri u = richiesta.getUrl();
                String mio = getString(R.string.indirizzo_app);
                // i link verso fuori si aprono nel browser, il resto resta dentro
                if (u.toString().startsWith(mio)) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) { return false; }
                return true;
            }
        });

        vista.addJavascriptInterface(new Ponte(this), "CoachNativo");
        Avvisi.creaCanali(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            chiediNotifiche.launch(Manifest.permission.POST_NOTIFICATIONS);
        }

        vista.loadUrl(getString(R.string.indirizzo_app));
    }

    @Override
    public boolean onKeyDown(int codice, KeyEvent evento) {
        if (codice == KeyEvent.KEYCODE_BACK && vista.canGoBack()) {
            vista.goBack();
            return true;
        }
        return super.onKeyDown(codice, evento);
    }
}
