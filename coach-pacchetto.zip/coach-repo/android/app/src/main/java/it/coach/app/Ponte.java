package it.coach.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * Il ponte fra la pagina web e il telefono.
 * Dentro la pagina si chiama CoachNativo: se esiste, l'app gira dentro l'involucro.
 */
public class Ponte {

    private final Activity ctx;
    private static final String PREF = "coach_programmate";

    public Ponte(Activity ctx) { this.ctx = ctx; }

    @JavascriptInterface
    public boolean disponibile() { return true; }

    @JavascriptInterface
    public String versione() { return "2.2"; }

    /* ---------- notifiche programmate ---------- */

    @JavascriptInterface
    public void programma(String id, String titolo, String testo, double quando, boolean forte) {
        long ms = (long) quando;
        if (ms <= System.currentTimeMillis()) return;
        metti(ctx, id, titolo, testo, ms, forte);
        ricorda(ctx, id, titolo, testo, ms, forte);
    }

    @JavascriptInterface
    public void annulla(String id) {
        AlarmManager am = ctx.getSystemService(AlarmManager.class);
        if (am != null) am.cancel(pending(ctx, id, null, null, false));
        dimenticaProgrammata(ctx, id);
    }

    @JavascriptInterface
    public void annullaTutte() {
        SharedPreferences p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        try {
            JSONArray a = new JSONArray(p.getString("lista", "[]"));
            AlarmManager am = ctx.getSystemService(AlarmManager.class);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (am != null) am.cancel(pending(ctx, o.getString("id"), null, null, false));
            }
        } catch (Exception ignored) { }
        p.edit().putString("lista", "[]").apply();
    }

    @JavascriptInterface
    public int quanteProgrammate() {
        try {
            return new JSONArray(ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .getString("lista", "[]")).length();
        } catch (Exception e) { return 0; }
    }

    /* ---------- sveglia e timer del telefono ---------- */

    @JavascriptInterface
    public boolean sveglia(int ora, int minuti, String etichetta) {
        final Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, ora)
                .putExtra(AlarmClock.EXTRA_MINUTES, minuti)
                .putExtra(AlarmClock.EXTRA_MESSAGE, etichetta == null ? "Coach" : etichetta)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return lancia(i);
    }

    @JavascriptInterface
    public boolean timer(int secondi, String etichetta) {
        final Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secondi)
                .putExtra(AlarmClock.EXTRA_MESSAGE, etichetta == null ? "Coach" : etichetta)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return lancia(i);
    }

    /* aprire un'altra app va fatto dal thread dell'interfaccia, non da quello del browser */
    private boolean lancia(final Intent i) {
        final boolean[] ok = { false };
        try {
            ctx.runOnUiThread(new Runnable() {
                @Override public void run() {
                    try { ctx.startActivity(i); ok[0] = true; }
                    catch (Exception e) { ok[0] = false; }
                }
            });
            return true;
        } catch (Exception e) { return false; }
    }

    @JavascriptInterface
    public void vibra(int ms) {
        Vibrator v = ctx.getSystemService(Vibrator.class);
        if (v == null) return;
        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
    }

    /* ---------- permessi ---------- */

    @JavascriptInterface
    public boolean puoEsatte() {
        AlarmManager am = ctx.getSystemService(AlarmManager.class);
        if (am == null) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) return am.canScheduleExactAlarms();
        return true;
    }

    @JavascriptInterface
    public void apriImpostazioniSveglie() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;
        try {
            ctx.startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + ctx.getPackageName()))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void apriImpostazioniApp() {
        try {
            ctx.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + ctx.getPackageName()))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) { }
    }

    /* ---------- il calendario del telefono ----------
       Google Calendar è già sincronizzato sul telefono: lo leggiamo da lì,
       senza token e senza internet. Solo lettura. */

    @JavascriptInterface
    public boolean calendarioConcesso() {
        return ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR)
                == PackageManager.PERMISSION_GRANTED;
    }

    @JavascriptInterface
    public void chiediCalendario() {
        if (ctx instanceof MainActivity) ((MainActivity) ctx).domandaCalendario();
    }

    /** I calendari presenti sul telefono, per scegliere quali leggere. */
    @JavascriptInterface
    public String calendari() {
        JSONArray out = new JSONArray();
        if (!calendarioConcesso()) return out.toString();
        String[] campi = {
                CalendarContract.Calendars._ID,
                CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
                CalendarContract.Calendars.ACCOUNT_NAME,
                CalendarContract.Calendars.CALENDAR_COLOR,
                CalendarContract.Calendars.VISIBLE
        };
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(CalendarContract.Calendars.CONTENT_URI, campi, null, null, null);
            while (c != null && c.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("id", String.valueOf(c.getLong(0)));
                o.put("nome", c.getString(1));
                o.put("account", c.getString(2));
                o.put("colore", String.format("#%06X", 0xFFFFFF & c.getInt(3)));
                o.put("visibile", c.getInt(4) == 1);
                out.put(o);
            }
        } catch (Exception ignored) {
        } finally { if (c != null) c.close(); }
        return out.toString();
    }

    /** Tutte le occorrenze fra due istanti (millisecondi), già espanse dalle ripetizioni. */
    @JavascriptInterface
    public String leggiCalendario(double da, double a) {
        JSONArray out = new JSONArray();
        if (!calendarioConcesso()) return out.toString();
        Uri.Builder b = CalendarContract.Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(b, (long) da);
        ContentUris.appendId(b, (long) a);
        String[] campi = {
                CalendarContract.Instances.EVENT_ID,          // 0
                CalendarContract.Instances.BEGIN,             // 1
                CalendarContract.Instances.END,               // 2
                CalendarContract.Instances.TITLE,             // 3
                CalendarContract.Instances.ALL_DAY,           // 4
                CalendarContract.Instances.RRULE,             // 5
                CalendarContract.Instances.ORIGINAL_ID,       // 6
                CalendarContract.Instances.EVENT_LOCATION,    // 7
                CalendarContract.Instances.DESCRIPTION,       // 8
                CalendarContract.Instances.AVAILABILITY,      // 9
                CalendarContract.Instances.STATUS,            // 10
                CalendarContract.Instances.CALENDAR_ID,       // 11
                CalendarContract.Instances.CALENDAR_DISPLAY_NAME, // 12
                CalendarContract.Instances.SELF_ATTENDEE_STATUS,  // 13
                CalendarContract.Instances.VISIBLE,           // 14
                CalendarContract.Instances.ORIGINAL_SYNC_ID   // 15
        };
        java.util.ArrayList<JSONObject> righe = new java.util.ArrayList<>();
        java.util.LinkedHashSet<String> idEventi = new java.util.LinkedHashSet<>();
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(b.build(), campi, null, null,
                    CalendarContract.Instances.BEGIN + " ASC");
            while (c != null && c.moveToNext()) {
                if (c.getInt(10) == CalendarContract.Events.STATUS_CANCELED) continue;
                if (c.getInt(13) == CalendarContract.Attendees.ATTENDEE_STATUS_DECLINED) continue;
                JSONObject o = new JSONObject();
                o.put("id", String.valueOf(c.getLong(0)));
                o.put("inizio", c.getLong(1));
                o.put("fine", c.getLong(2));
                o.put("titolo", c.isNull(3) ? "" : c.getString(3));
                o.put("tuttoIlGiorno", c.getInt(4) == 1);
                o.put("regola", c.isNull(5) ? "" : c.getString(5));
                o.put("serie", c.isNull(6) ? "" : String.valueOf(c.getLong(6)));
                o.put("luogo", c.isNull(7) ? "" : c.getString(7));
                o.put("note", c.isNull(8) ? "" : c.getString(8));
                o.put("libero", c.getInt(9) == CalendarContract.Events.AVAILABILITY_FREE);
                o.put("calendario", String.valueOf(c.getLong(11)));
                o.put("nomeCalendario", c.isNull(12) ? "" : c.getString(12));
                o.put("visibile", c.getInt(14) == 1);
                o.put("gserie", c.isNull(15) ? "" : c.getString(15));
                righe.add(o);
                idEventi.add(String.valueOf(c.getLong(0)));
            }
        } catch (Exception e) {
            return "{\"errore\":" + JSONObject.quote(String.valueOf(e.getMessage())) + "}";
        } finally { if (c != null) c.close(); }

        // L'id locale cambia da un telefono all'altro; quello di Google no.
        // Serve per ritrovare i dettagli aggiunti su ogni dispositivo.
        java.util.HashMap<String, String> diGoogle = new java.util.HashMap<>();
        java.util.ArrayList<String> tutti = new java.util.ArrayList<>(idEventi);
        for (int da0 = 0; da0 < tutti.size(); da0 += 400) {
            java.util.List<String> pezzo = tutti.subList(da0, Math.min(tutti.size(), da0 + 400));
            Cursor e = null;
            try {
                e = ctx.getContentResolver().query(CalendarContract.Events.CONTENT_URI,
                        new String[]{ CalendarContract.Events._ID, CalendarContract.Events._SYNC_ID },
                        CalendarContract.Events._ID + " IN (" + android.text.TextUtils.join(",", pezzo) + ")",
                        null, null);
                while (e != null && e.moveToNext())
                    if (!e.isNull(1)) diGoogle.put(String.valueOf(e.getLong(0)), e.getString(1));
            } catch (Exception ignored) {
            } finally { if (e != null) e.close(); }
        }
        try {
            for (JSONObject o : righe) {
                String g = diGoogle.get(o.getString("id"));
                o.put("gid", g == null ? "" : g);
                out.put(o);
            }
        } catch (Exception ignored) { }
        return out.toString();
    }

    /* ---------- file: aprire un documento, salvare un backup ---------- */

    private File scriviInCache(String base64, String nome) throws Exception {
        File dir = new File(ctx.getCacheDir(), "documenti");
        if (!dir.exists()) dir.mkdirs();
        String pulito = (nome == null || nome.isEmpty() ? "documento" : nome).replaceAll("[\\\\/:*?\"<>|]", "_");
        File f = new File(dir, pulito);
        byte[] dati = Base64.decode(base64, Base64.DEFAULT);
        FileOutputStream fo = new FileOutputStream(f);
        try { fo.write(dati); } finally { fo.close(); }
        return f;
    }

    /** Apre un documento (PDF, foto…) con l'app giusta del telefono. */
    @JavascriptInterface
    public String apriFile(String base64, String tipo, String nome) {
        try {
            File f = scriviInCache(base64, nome);
            Uri u = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".file", f);
            Intent i = new Intent(Intent.ACTION_VIEW)
                    .setDataAndType(u, tipo == null || tipo.isEmpty() ? "*/*" : tipo)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent scelta = Intent.createChooser(i, nome).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            lancia(scelta);
            return "ok";
        } catch (Exception e) { return "errore: " + e.getMessage(); }
    }

    /** Manda un file altrove: Drive, email, la cartella Download… */
    @JavascriptInterface
    public String condividiFile(String base64, String tipo, String nome) {
        try {
            File f = scriviInCache(base64, nome);
            Uri u = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".file", f);
            Intent i = new Intent(Intent.ACTION_SEND)
                    .setType(tipo == null || tipo.isEmpty() ? "*/*" : tipo)
                    .putExtra(Intent.EXTRA_STREAM, u)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent scelta = Intent.createChooser(i, nome).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            lancia(scelta);
            return "ok";
        } catch (Exception e) { return "errore: " + e.getMessage(); }
    }

    /** Salva un file nella cartella Download del telefono. */
    @JavascriptInterface
    public String salvaFile(String base64, String tipo, String nome) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return condividiFile(base64, tipo, nome);
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, nome);
            v.put(MediaStore.Downloads.MIME_TYPE, tipo == null || tipo.isEmpty() ? "application/octet-stream" : tipo);
            Uri u = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) return "errore: nessuna cartella";
            OutputStream os = ctx.getContentResolver().openOutputStream(u);
            if (os == null) return "errore: non scrivibile";
            try { os.write(Base64.decode(base64, Base64.DEFAULT)); } finally { os.close(); }
            return "ok";
        } catch (Exception e) { return "errore: " + e.getMessage(); }
    }

    /* ---------- internet senza i limiti del browser ----------
       Alcuni servizi (l'archivio dei titoli) non rispondono alle pagine web:
       la richiesta la fa il telefono e la risposta torna alla pagina. */
    @JavascriptInterface
    public void richiesta(final String id, final String metodo, final String indirizzo,
                          final String corpo, final String tipo) {
        new Thread(() -> {
            JSONObject r = new JSONObject();
            HttpURLConnection c = null;
            try {
                if (indirizzo == null || !indirizzo.startsWith("https://")) throw new Exception("solo https");
                c = (HttpURLConnection) new URL(indirizzo).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                c.setRequestMethod(metodo == null || metodo.isEmpty() ? "GET" : metodo);
                c.setRequestProperty("Accept", "application/json");
                if (corpo != null && !corpo.isEmpty()) {
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", tipo == null || tipo.isEmpty() ? "application/json" : tipo);
                    OutputStream os = c.getOutputStream();
                    try { os.write(corpo.getBytes("UTF-8")); } finally { os.close(); }
                }
                int stato = c.getResponseCode();
                InputStream in = stato >= 400 ? c.getErrorStream() : c.getInputStream();
                StringBuilder sb = new StringBuilder();
                if (in != null) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
                    try { String riga; while ((riga = br.readLine()) != null) sb.append(riga).append('\n'); }
                    finally { br.close(); }
                }
                r.put("stato", stato);
                r.put("corpo", sb.toString());
            } catch (Exception e) {
                try { r.put("stato", 0); r.put("errore", String.valueOf(e.getMessage())); } catch (Exception ignored) { }
            } finally { if (c != null) c.disconnect(); }
            if (ctx instanceof MainActivity) ((MainActivity) ctx).rispondi(id, r.toString());
        }).start();
    }

    /* ---------- la dettatura ---------- */
    @JavascriptInterface
    public void detta() {
        if (ctx instanceof MainActivity) ((MainActivity) ctx).avviaDettatura();
    }

    /* ---------- il widget della schermata Home ----------
       La pagina passa la giornata (oggi e domani); il widget la ridisegna
       e da lì in avanti si aggiorna da solo, anche ad app chiusa. */
    @JavascriptInterface
    public void aggiornaWidget(String json) {
        ctx.getSharedPreferences(CoachWidget.PREF, Context.MODE_PRIVATE)
                .edit().putString("dati", json == null ? "" : json).apply();
        CoachWidget.aggiornaTutti(ctx);
    }

    /* ---------- il lavoro sporco ---------- */

    private static PendingIntent pending(Context c, String id, String titolo, String testo, boolean forte) {
        Intent i = new Intent(c, Avvisatore.class)
                .putExtra("id", id)
                .putExtra("titolo", titolo)
                .putExtra("testo", testo)
                .putExtra("forte", forte);
        i.setData(Uri.parse("coach://" + id));
        return PendingIntent.getBroadcast(c, id.hashCode(), i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static void metti(Context c, String id, String titolo, String testo, long ms, boolean forte) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am == null) return;
        PendingIntent p = pending(c, id, titolo, testo, forte);
        boolean esatte = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms();
        if (esatte) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, p);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, p);
    }

    private static void ricorda(Context c, String id, String titolo, String testo, long ms, boolean forte) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        try {
            JSONArray a = new JSONArray(p.getString("lista", "[]"));
            JSONArray fuori = new JSONArray();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (!o.getString("id").equals(id) && o.getLong("quando") > System.currentTimeMillis())
                    fuori.put(o);
            }
            JSONObject n = new JSONObject();
            n.put("id", id); n.put("titolo", titolo); n.put("testo", testo);
            n.put("quando", ms); n.put("forte", forte);
            fuori.put(n);
            p.edit().putString("lista", fuori.toString()).apply();
        } catch (Exception ignored) { }
    }

    static void dimenticaProgrammata(Context c, String id) {
        if (id == null) return;
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        try {
            JSONArray a = new JSONArray(p.getString("lista", "[]"));
            JSONArray fuori = new JSONArray();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (!o.getString("id").equals(id)) fuori.put(o);
            }
            p.edit().putString("lista", fuori.toString()).apply();
        } catch (Exception ignored) { }
    }

    static void riprogrammaTutte(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        try {
            JSONArray a = new JSONArray(p.getString("lista", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                long quando = o.getLong("quando");
                if (quando > System.currentTimeMillis())
                    metti(c, o.getString("id"), o.optString("titolo"), o.optString("testo"),
                          quando, o.optBoolean("forte"));
            }
        } catch (Exception ignored) { }
    }
}
