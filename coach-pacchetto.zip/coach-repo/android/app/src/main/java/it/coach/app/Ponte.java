package it.coach.app;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.AlarmClock;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Il ponte fra la pagina web e il telefono.
 * Dentro la pagina si chiama CoachNativo: se esiste, l'app gira dentro l'involucro.
 */
public class Ponte {

    private final Activity ctx;
    private static final String PREF = "coach_programmate";

    public Ponte(Activity ctx) { this.ctx = ctx; }

    @JavascriptInterface
    public boolean disponibile() { return true; }

    @JavascriptInterface
    public String versione() { return "1.0"; }

    /* ---------- notifiche programmate ---------- */

    @JavascriptInterface
    public void programma(String id, String titolo, String testo, double quando, boolean forte) {
        long ms = (long) quando;
        if (ms <= System.currentTimeMillis()) return;
        metti(ctx, id, titolo, testo, ms, forte);
        ricorda(ctx, id, titolo, testo, ms, forte);
    }

    @JavascriptInterface
    public void annulla(String id) {
        AlarmManager am = ctx.getSystemService(AlarmManager.class);
        if (am != null) am.cancel(pending(ctx, id, null, null, false));
        dimenticaProgrammata(ctx, id);
    }

    @JavascriptInterface
    public void annullaTutte() {
        SharedPreferences p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        try {
            JSONArray a = new JSONArray(p.getString("lista", "[]"));
            AlarmManager am = ctx.getSystemService(AlarmManager.class);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (am != null) am.cancel(pending(ctx, o.getString("id"), null, null, false));
            }
        } catch (Exception ignored) { }
        p.edit().putString("lista", "[]").apply();
    }

    @JavascriptInterface
    public int quanteProgrammate() {
        try {
            return new JSONArray(ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .getString("lista", "[]")).length();
        } catch (Exception e) { return 0; }
    }

    /* ---------- sveglia e timer del telefono ---------- */

    @JavascriptInterface
    public void sveglia(int ora, int minuti, String etichetta) {
        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, ora)
                .putExtra(AlarmClock.EXTRA_MINUTES, minuti)
                .putExtra(AlarmClock.EXTRA_MESSAGE, etichetta == null ? "Coach" : etichetta)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { ctx.startActivity(i); } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void timer(int secondi, String etichetta) {
        Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secondi)
                .putExtra(AlarmClock.EXTRA_MESSAGE, etichetta == null ? "Coach" : etichetta)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { ctx.startActivity(i); } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void vibra(int ms) {
        Vibrator v = ctx.getSystemService(Vibrator.class);
        if (v == null) return;
        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
    }

    /* ---------- permessi ---------- */

    @JavascriptInterface
    public boolean puoEsatte() {
        AlarmManager am = ctx.getSystemService(AlarmManager.class);
        if (am == null) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) return am.canScheduleExactAlarms();
        return true;
    }

    @JavascriptInterface
    public void apriImpostazioniSveglie() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;
        try {
            ctx.startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + ctx.getPackageName()))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public void apriImpostazioniApp() {
        try {
            ctx.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + ctx.getPackageName()))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception ignored) { }
    }

    /* ---------- il lavoro sporco ---------- */

    private static PendingIntent pending(Context c, String id, String titolo, String testo, boolean forte) {
        Intent i = new Intent(c, Avvisatore.class)
                .putExtra("id", id)
                .putExtra("titolo", titolo)
                .putExtra("testo", testo)
                .putExtra("forte", forte);
        i.setData(Uri.parse("coach://" + id));
        return PendingIntent.getBroadcast(c, id.hashCode(), i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static void metti(Context c, String id, String titolo, String testo, long ms, boolean forte) {
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am == null) return;
        PendingIntent p = pending(c, id, titolo, testo, forte);
        boolean esatte = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms();
        if (esatte) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, p);
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, p);
    }

    private static void ricorda(Context c, String id, String titolo, String testo, long ms, boolean forte) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        try {
            JSONArray a = new JSONArray(p.getString("lista", "[]"));
            JSONArray fuori = new JSONArray();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (!o.getString("id").equals(id) && o.getLong("quando") > System.currentTimeMillis())
                    fuori.put(o);
            }
            JSONObject n = new JSONObject();
            n.put("id", id); n.put("titolo", titolo); n.put("testo", testo);
            n.put("quando", ms); n.put("forte", forte);
            fuori.put(n);
            p.edit().putString("lista", fuori.toString()).apply();
        } catch (Exception ignored) { }
    }

    static void dimenticaProgrammata(Context c, String id) {
        if (id == null) return;
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        try {
            JSONArray a = new JSONArray(p.getString("lista", "[]"));
            JSONArray fuori = new JSONArray();
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                if (!o.getString("id").equals(id)) fuori.put(o);
            }
            p.edit().putString("lista", fuori.toString()).apply();
        } catch (Exception ignored) { }
    }

    static void riprogrammaTutte(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        try {
            JSONArray a = new JSONArray(p.getString("lista", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                long quando = o.getLong("quando");
                if (quando > System.currentTimeMillis())
                    metti(c, o.getString("id"), o.optString("titolo"), o.optString("testo"),
                          quando, o.optBoolean("forte"));
            }
        } catch (Exception ignored) { }
    }
}
