package it.coach.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

/**
 * Scatta all'ora giusta e mostra la notifica.
 * Se è una sveglia suona come quella del mattino, finché non la fermi:
 * si accende lo schermo con "Ferma" e "Fra 5 minuti".
 */
public class Avvisatore extends BroadcastReceiver {

    static final String FERMA = "it.coach.app.SVEGLIA_FERMA";
    static final String POSTICIPA = "it.coach.app.SVEGLIA_POSTICIPA";
    static final int MINUTI_POSTICIPA = 5;
    static final int MINUTI_SUONA = 10;

    @Override
    public void onReceive(Context c, Intent intent) {
        if (intent == null) return;
        String id = intent.getStringExtra("id");
        String titolo = intent.getStringExtra("titolo");
        String testo = intent.getStringExtra("testo");
        if (titolo == null) titolo = "Coach";
        if (testo == null) testo = "";

        // i tasti della sveglia
        if (FERMA.equals(intent.getAction())) { ferma(c, id); return; }
        if (POSTICIPA.equals(intent.getAction())) { posticipa(c, id, titolo, testo); return; }

        Avvisi.creaCanali(c);
        boolean sveglia = intent.getBooleanExtra("sveglia", false);
        boolean forte = intent.getBooleanExtra("forte", false);

        Intent apri = new Intent(c, MainActivity.class);
        apri.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tocco = PendingIntent.getActivity(
                c, (id != null ? id.hashCode() : 0), apri,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationManager nm = c.getSystemService(NotificationManager.class);
        int numero = id != null ? id.hashCode() : (int) System.currentTimeMillis();

        if (sveglia) {
            Intent schermo = new Intent(c, SvegliaActivity.class)
                    .putExtra("id", id).putExtra("titolo", titolo).putExtra("testo", testo)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
            PendingIntent pieno = PendingIntent.getActivity(c, numero, schermo,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            NotificationCompat.Builder b = new NotificationCompat.Builder(c, Avvisi.CANALE_SVEGLIA)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setContentTitle(titolo)
                    .setContentText(testo)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(testo))
                    .setCategory(NotificationCompat.CATEGORY_ALARM)
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setOngoing(true)
                    .setAutoCancel(false)
                    .setContentIntent(pieno)
                    .setFullScreenIntent(pieno, true)
                    .addAction(0, "Ferma", tasto(c, FERMA, id, titolo, testo))
                    .addAction(0, "Fra " + MINUTI_POSTICIPA + " minuti", tasto(c, POSTICIPA, id, titolo, testo));
            Notification n = b.build();
            n.flags |= Notification.FLAG_INSISTENT;          // il suono si ripete finché non la fermi
            if (nm != null) nm.notify(numero, n);
            // se nessuno la ferma, dopo dieci minuti tace da sola
            AlarmManager am = c.getSystemService(AlarmManager.class);
            if (am != null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                    System.currentTimeMillis() + MINUTI_SUONA * 60000L, tasto(c, FERMA, id, titolo, testo));
        } else {
            NotificationCompat.Builder b = new NotificationCompat.Builder(
                    c, forte ? Avvisi.CANALE_FORTE : Avvisi.CANALE)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle(titolo)
                    .setContentText(testo)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(testo))
                    .setAutoCancel(true)
                    .setContentIntent(tocco)
                    .setPriority(forte ? NotificationCompat.PRIORITY_HIGH : NotificationCompat.PRIORITY_DEFAULT);
            if (nm != null) nm.notify(numero, b.build());
        }

        Ponte.dimenticaProgrammata(c, id);
    }

    private static PendingIntent tasto(Context c, String azione, String id, String titolo, String testo) {
        Intent i = new Intent(c, Avvisatore.class).setAction(azione)
                .putExtra("id", id).putExtra("titolo", titolo).putExtra("testo", testo);
        int codice = ((id != null ? id : "") + azione).hashCode();
        return PendingIntent.getBroadcast(c, codice, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Spegne la sveglia: via la notifica, e con lei il suono. */
    static void ferma(Context c, String id) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null && id != null) nm.cancel(id.hashCode());
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am != null) am.cancel(tasto(c, FERMA, id, null, null));      // non serve più spegnerla da sola
        SvegliaActivity.chiudiSeAperta(id);
    }

    /** Fra cinque minuti suona di nuovo. */
    static void posticipa(Context c, String id, String titolo, String testo) {
        ferma(c, id);
        String base = id != null ? id : "sveglia";
        String nuovo = base.endsWith("-dopo") ? base : base + "-dopo";   // rimandarla ancora non moltiplica le sveglie
        Ponte.mettiSveglia(c, nuovo, titolo, testo, System.currentTimeMillis() + MINUTI_POSTICIPA * 60000L);
    }
}
