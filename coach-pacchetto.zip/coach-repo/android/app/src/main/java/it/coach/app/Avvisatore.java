package it.coach.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

/**
 * Scatta all'ora giusta e mostra la notifica.
 * Se è una sveglia suona come quella del mattino, finché non la fermi:
 * si accende lo schermo con "Ferma" e "Fra 5 minuti".
 */
public class Avvisatore extends BroadcastReceiver {

    static final String FERMA = "it.coach.app.SVEGLIA_FERMA";
    static final String POSTICIPA = "it.coach.app.SVEGLIA_POSTICIPA";
    static final String RIMANDA = "it.coach.app.GIORNATA_RIMANDA";
    static final int MINUTI_POSTICIPA = 5;
    static final int MINUTI_SUONA = 10;
    static final int MINUTI_RIMANDA = 30;

    @Override
    public void onReceive(Context c, Intent intent) {
        if (intent == null) return;
        String id = intent.getStringExtra("id");
        String titolo = intent.getStringExtra("titolo");
        String testo = intent.getStringExtra("testo");
        if (titolo == null) titolo = "Coach";
        if (testo == null) testo = "";

        // i tasti della sveglia
        if (FERMA.equals(intent.getAction())) { ferma(c, id); return; }
        if (POSTICIPA.equals(intent.getAction())) { posticipa(c, id, titolo, testo); return; }
        if (RIMANDA.equals(intent.getAction())) { rimanda(c, id, titolo, testo, intent.getStringExtra("schermo")); return; }

        Avvisi.creaCanali(c);
        boolean sveglia = intent.getBooleanExtra("sveglia", false);
        boolean forte = intent.getBooleanExtra("forte", false);

        Intent apri = new Intent(c, MainActivity.class);
        apri.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tocco = PendingIntent.getActivity(
                c, (id != null ? id.hashCode() : 0), apri,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationManager nm = c.getSystemService(NotificationManager.class);
        int numero = id != null ? id.hashCode() : (int) System.currentTimeMillis();
        String schermoTipo = intent.getStringExtra("schermo");

        if (schermoTipo != null && !sveglia) {
            // la giornata in breve, la chiusura serale, o uno schermo con un tasto suo ("az:settimana:Pianifichiamo")
            boolean sera = "sera".equals(schermoTipo);
            String azione = sera ? "chiudi" : "breve", etichetta = sera ? "Chiudi la giornata" : "Apri la giornata";
            boolean suo = schermoTipo.startsWith("az:");
            if (suo) {
                String[] p = schermoTipo.split(":", 3);
                azione = p.length > 1 && !p[1].isEmpty() ? p[1] : "breve";
                etichetta = p.length > 2 && !p[2].isEmpty() ? p[2] : "Apri Coach";
            }
            Intent pagina = new Intent(c, GiornataActivity.class)
                    .putExtra("id", id).putExtra("titolo", titolo).putExtra("testo", testo).putExtra("tipo", schermoTipo)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
            PendingIntent pieno = PendingIntent.getActivity(c, numero, pagina,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            NotificationCompat.Builder b = new NotificationCompat.Builder(c, Avvisi.CANALE_GIORNATA)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle(titolo)
                    .setContentText(testo)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(testo))
                    .setCategory(NotificationCompat.CATEGORY_REMINDER)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setAutoCancel(true)
                    .setContentIntent(apriCon(c, azione, numero))
                    .setFullScreenIntent(pieno, true)
                    .addAction(0, etichetta, apriCon(c, azione, numero));
            if (sera || suo) b.addAction(0, "Fra " + MINUTI_RIMANDA + " minuti", tastoRimanda(c, id, titolo, testo, schermoTipo));
            if (nm != null) nm.notify(numero, b.build());
            Ponte.dimenticaProgrammata(c, id);
            return;
        }

        if (sveglia) {
            Intent schermo = new Intent(c, SvegliaActivity.class)
                    .putExtra("id", id).putExtra("titolo", titolo).putExtra("testo", testo)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_USER_ACTION);
            PendingIntent pieno = PendingIntent.getActivity(c, numero, schermo,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            NotificationCompat.Builder b = new NotificationCompat.Builder(c, Avvisi.CANALE_SVEGLIA)
                    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                    .setContentTitle(titolo)
                    .setContentText(testo)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(testo))
                    .setCategory(NotificationCompat.CATEGORY_ALARM)
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setOngoing(true)
                    .setAutoCancel(false)
                    .setContentIntent(pieno)
                    .setFullScreenIntent(pieno, true)
                    .addAction(0, "Ferma", tasto(c, FERMA, id, titolo, testo))
                    .addAction(0, "Fra " + MINUTI_POSTICIPA + " minuti", tasto(c, POSTICIPA, id, titolo, testo));
            Notification n = b.build();
            n.flags |= Notification.FLAG_INSISTENT;          // il suono si ripete finché non la fermi
            if (nm != null) nm.notify(numero, n);
            // se nessuno la ferma, dopo dieci minuti tace da sola
            AlarmManager am = c.getSystemService(AlarmManager.class);
            if (am != null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                    System.currentTimeMillis() + MINUTI_SUONA * 60000L, tasto(c, FERMA, id, titolo, testo));
        } else {
            NotificationCompat.Builder b = new NotificationCompat.Builder(
                    c, forte ? Avvisi.CANALE_FORTE : Avvisi.CANALE)
                    .setSmallIcon(android.R.drawable.ic_popup_reminder)
                    .setContentTitle(titolo)
                    .setContentText(testo)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(testo))
                    .setAutoCancel(true)
                    .setContentIntent(tocco)
                    .setPriority(forte ? NotificationCompat.PRIORITY_HIGH : NotificationCompat.PRIORITY_DEFAULT);
            if (nm != null) nm.notify(numero, b.build());
        }

        Ponte.dimenticaProgrammata(c, id);
    }

    private static PendingIntent tasto(Context c, String azione, String id, String titolo, String testo) {
        Intent i = new Intent(c, Avvisatore.class).setAction(azione)
                .putExtra("id", id).putExtra("titolo", titolo).putExtra("testo", testo);
        int codice = ((id != null ? id : "") + azione).hashCode();
        return PendingIntent.getBroadcast(c, codice, i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** Apre Coach su un'azione ("breve", "chiudi") e toglie la notifica. */
    static PendingIntent apriCon(Context c, String azione, int numero) {
        Intent i = new Intent(c, MainActivity.class)
                .setAction("it.coach.app.APRI_" + azione)
                .putExtra("azione", azione)
                .putExtra("notifica", numero)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, numero + azione.hashCode(), i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private static PendingIntent tastoRimanda(Context c, String id, String titolo, String testo, String tipo) {
        Intent i = new Intent(c, Avvisatore.class).setAction(RIMANDA)
                .putExtra("id", id).putExtra("titolo", titolo).putExtra("testo", testo).putExtra("schermo", tipo);
        return PendingIntent.getBroadcast(c, ((id != null ? id : "") + RIMANDA).hashCode(), i,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    /** La chiusura fra mezz'ora: via la notifica, e lo schermo torna più tardi. */
    static void rimanda(Context c, String id, String titolo, String testo, String tipo) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null && id != null) nm.cancel(id.hashCode());
        GiornataActivity.chiudiSeAperta(id);
        String base = id != null ? id : "giornata";
        String nuovo = base.endsWith("-dopo") ? base : base + "-dopo";
        Ponte.mettiSchermo(c, nuovo, titolo, testo, System.currentTimeMillis() + MINUTI_RIMANDA * 60000L,
                tipo != null ? tipo : "sera");
    }

    /** Spegne la sveglia: via la notifica, e con lei il suono. */
    static void ferma(Context c, String id) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null && id != null) nm.cancel(id.hashCode());
        AlarmManager am = c.getSystemService(AlarmManager.class);
        if (am != null) am.cancel(tasto(c, FERMA, id, null, null));      // non serve più spegnerla da sola
        SvegliaActivity.chiudiSeAperta(id);
    }

    /** Fra cinque minuti suona di nuovo. */
    static void posticipa(Context c, String id, String titolo, String testo) {
        ferma(c, id);
        String base = id != null ? id : "sveglia";
        String nuovo = base.endsWith("-dopo") ? base : base + "-dopo";   // rimandarla ancora non moltiplica le sveglie
        Ponte.mettiSveglia(c, nuovo, titolo, testo, System.currentTimeMillis() + MINUTI_POSTICIPA * 60000L);
    }
}
