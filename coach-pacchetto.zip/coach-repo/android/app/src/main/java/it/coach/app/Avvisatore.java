package it.coach.app;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

/** Scatta all'ora giusta e mostra la notifica. */
public class Avvisatore extends BroadcastReceiver {

    @Override
    public void onReceive(Context c, Intent intent) {
        String id = intent.getStringExtra("id");
        String titolo = intent.getStringExtra("titolo");
        String testo = intent.getStringExtra("testo");
        boolean forte = intent.getBooleanExtra("forte", false);
        if (titolo == null) titolo = "Coach";

        Intent apri = new Intent(c, MainActivity.class);
        apri.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent tocco = PendingIntent.getActivity(
                c, (id != null ? id.hashCode() : 0), apri,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder b = new NotificationCompat.Builder(
                c, forte ? Avvisi.CANALE_FORTE : Avvisi.CANALE)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(titolo)
                .setContentText(testo)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(testo))
                .setAutoCancel(true)
                .setContentIntent(tocco)
                .setPriority(forte ? NotificationCompat.PRIORITY_HIGH : NotificationCompat.PRIORITY_DEFAULT);

        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null) nm.notify(id != null ? id.hashCode() : (int) System.currentTimeMillis(), b.build());

        Ponte.dimenticaProgrammata(c, id);
    }
}
